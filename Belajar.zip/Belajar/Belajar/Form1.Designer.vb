﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim GradientFillColor1 As DevComponents.Instrumentation.GradientFillColor = New DevComponents.Instrumentation.GradientFillColor()
        Dim GradientFillColor2 As DevComponents.Instrumentation.GradientFillColor = New DevComponents.Instrumentation.GradientFillColor()
        Dim GaugeText1 As DevComponents.Instrumentation.GaugeText = New DevComponents.Instrumentation.GaugeText()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Dim GaugeText2 As DevComponents.Instrumentation.GaugeText = New DevComponents.Instrumentation.GaugeText()
        Dim GaugeLinearScale1 As DevComponents.Instrumentation.GaugeLinearScale = New DevComponents.Instrumentation.GaugeLinearScale()
        Dim GaugePointer1 As DevComponents.Instrumentation.GaugePointer = New DevComponents.Instrumentation.GaugePointer()
        Dim GaugeSection1 As DevComponents.Instrumentation.GaugeSection = New DevComponents.Instrumentation.GaugeSection()
        Dim GaugeLinearScale2 As DevComponents.Instrumentation.GaugeLinearScale = New DevComponents.Instrumentation.GaugeLinearScale()
        Dim GradientFillColor3 As DevComponents.Instrumentation.GradientFillColor = New DevComponents.Instrumentation.GradientFillColor()
        Dim GradientFillColor4 As DevComponents.Instrumentation.GradientFillColor = New DevComponents.Instrumentation.GradientFillColor()
        Dim GaugeLinearScale3 As DevComponents.Instrumentation.GaugeLinearScale = New DevComponents.Instrumentation.GaugeLinearScale()
        Dim GaugeCustomLabel1 As DevComponents.Instrumentation.GaugeCustomLabel = New DevComponents.Instrumentation.GaugeCustomLabel()
        Dim GaugeCustomLabel2 As DevComponents.Instrumentation.GaugeCustomLabel = New DevComponents.Instrumentation.GaugeCustomLabel()
        Dim GaugeCustomLabel3 As DevComponents.Instrumentation.GaugeCustomLabel = New DevComponents.Instrumentation.GaugeCustomLabel()
        Dim GaugePointer2 As DevComponents.Instrumentation.GaugePointer = New DevComponents.Instrumentation.GaugePointer()
        Dim GaugeSection2 As DevComponents.Instrumentation.GaugeSection = New DevComponents.Instrumentation.GaugeSection()
        Me.Bt_Scan = New System.Windows.Forms.Button()
        Me.Cb_Scan = New System.Windows.Forms.ComboBox()
        Me.Cb_Baud = New System.Windows.Forms.ComboBox()
        Me.Bt_Baud = New System.Windows.Forms.Button()
        Me.Bt_Connect = New System.Windows.Forms.Button()
        Me.Bt_Disconnect = New System.Windows.Forms.Button()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Tx_suhu = New System.Windows.Forms.TextBox()
        Me.Tx_data = New System.Windows.Forms.TextBox()
        Me.Tx_pH = New System.Windows.Forms.TextBox()
        Me.Lb_data = New System.Windows.Forms.Label()
        Me.Lb_ph = New System.Windows.Forms.Label()
        Me.Lb_suhu = New System.Windows.Forms.Label()
        Me.Pc_Status = New System.Windows.Forms.PictureBox()
        Me.Bt_Save = New System.Windows.Forms.Button()
        Me.Bt_Delete = New System.Windows.Forms.Button()
        Me.Bt_Close = New System.Windows.Forms.Button()
        Me.DGV = New System.Windows.Forms.DataGridView()
        Me.Tx_Date = New System.Windows.Forms.TextBox()
        Me.Tx_Time = New System.Windows.Forms.TextBox()
        Me.GC1 = New DevComponents.Instrumentation.GaugeControl()
        Me.GC2 = New DevComponents.Instrumentation.GaugeControl()
        CType(Me.Pc_Status, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GC1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GC2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Bt_Scan
        '
        Me.Bt_Scan.Location = New System.Drawing.Point(12, 16)
        Me.Bt_Scan.Name = "Bt_Scan"
        Me.Bt_Scan.Size = New System.Drawing.Size(75, 23)
        Me.Bt_Scan.TabIndex = 0
        Me.Bt_Scan.Text = "SCAN"
        Me.Bt_Scan.UseVisualStyleBackColor = True
        '
        'Cb_Scan
        '
        Me.Cb_Scan.FormattingEnabled = True
        Me.Cb_Scan.Location = New System.Drawing.Point(105, 16)
        Me.Cb_Scan.Name = "Cb_Scan"
        Me.Cb_Scan.Size = New System.Drawing.Size(121, 21)
        Me.Cb_Scan.TabIndex = 1
        '
        'Cb_Baud
        '
        Me.Cb_Baud.FormattingEnabled = True
        Me.Cb_Baud.Items.AddRange(New Object() {"1200", "2400", "4800", "9600", "19200", "38400", "57600", "74880", "115200"})
        Me.Cb_Baud.Location = New System.Drawing.Point(104, 56)
        Me.Cb_Baud.Name = "Cb_Baud"
        Me.Cb_Baud.Size = New System.Drawing.Size(121, 21)
        Me.Cb_Baud.TabIndex = 3
        '
        'Bt_Baud
        '
        Me.Bt_Baud.Location = New System.Drawing.Point(11, 56)
        Me.Bt_Baud.Name = "Bt_Baud"
        Me.Bt_Baud.Size = New System.Drawing.Size(75, 23)
        Me.Bt_Baud.TabIndex = 2
        Me.Bt_Baud.Text = "BAUDRATE"
        Me.Bt_Baud.UseVisualStyleBackColor = True
        '
        'Bt_Connect
        '
        Me.Bt_Connect.Location = New System.Drawing.Point(12, 97)
        Me.Bt_Connect.Name = "Bt_Connect"
        Me.Bt_Connect.Size = New System.Drawing.Size(75, 23)
        Me.Bt_Connect.TabIndex = 4
        Me.Bt_Connect.Text = "CONNECT"
        Me.Bt_Connect.UseVisualStyleBackColor = True
        '
        'Bt_Disconnect
        '
        Me.Bt_Disconnect.Location = New System.Drawing.Point(140, 97)
        Me.Bt_Disconnect.Name = "Bt_Disconnect"
        Me.Bt_Disconnect.Size = New System.Drawing.Size(86, 23)
        Me.Bt_Disconnect.TabIndex = 5
        Me.Bt_Disconnect.Text = "DISCONNECT"
        Me.Bt_Disconnect.UseVisualStyleBackColor = True
        '
        'SerialPort1
        '
        '
        'Timer1
        '
        '
        'Timer2
        '
        '
        'Tx_suhu
        '
        Me.Tx_suhu.Location = New System.Drawing.Point(80, 216)
        Me.Tx_suhu.Name = "Tx_suhu"
        Me.Tx_suhu.Size = New System.Drawing.Size(52, 20)
        Me.Tx_suhu.TabIndex = 6
        '
        'Tx_data
        '
        Me.Tx_data.Location = New System.Drawing.Point(80, 145)
        Me.Tx_data.Name = "Tx_data"
        Me.Tx_data.Size = New System.Drawing.Size(52, 20)
        Me.Tx_data.TabIndex = 7
        '
        'Tx_pH
        '
        Me.Tx_pH.Location = New System.Drawing.Point(80, 180)
        Me.Tx_pH.Name = "Tx_pH"
        Me.Tx_pH.Size = New System.Drawing.Size(52, 20)
        Me.Tx_pH.TabIndex = 8
        '
        'Lb_data
        '
        Me.Lb_data.AutoSize = True
        Me.Lb_data.Location = New System.Drawing.Point(38, 145)
        Me.Lb_data.Name = "Lb_data"
        Me.Lb_data.Size = New System.Drawing.Size(36, 13)
        Me.Lb_data.TabIndex = 9
        Me.Lb_data.Text = "DATA"
        '
        'Lb_ph
        '
        Me.Lb_ph.AutoSize = True
        Me.Lb_ph.Location = New System.Drawing.Point(53, 183)
        Me.Lb_ph.Name = "Lb_ph"
        Me.Lb_ph.Size = New System.Drawing.Size(21, 13)
        Me.Lb_ph.TabIndex = 10
        Me.Lb_ph.Text = "pH"
        '
        'Lb_suhu
        '
        Me.Lb_suhu.AutoSize = True
        Me.Lb_suhu.Location = New System.Drawing.Point(42, 218)
        Me.Lb_suhu.Name = "Lb_suhu"
        Me.Lb_suhu.Size = New System.Drawing.Size(32, 13)
        Me.Lb_suhu.TabIndex = 11
        Me.Lb_suhu.Text = "Suhu"
        '
        'Pc_Status
        '
        Me.Pc_Status.BackColor = System.Drawing.Color.Red
        Me.Pc_Status.Location = New System.Drawing.Point(104, 97)
        Me.Pc_Status.Name = "Pc_Status"
        Me.Pc_Status.Size = New System.Drawing.Size(30, 25)
        Me.Pc_Status.TabIndex = 12
        Me.Pc_Status.TabStop = False
        '
        'Bt_Save
        '
        Me.Bt_Save.Location = New System.Drawing.Point(151, 145)
        Me.Bt_Save.Name = "Bt_Save"
        Me.Bt_Save.Size = New System.Drawing.Size(75, 23)
        Me.Bt_Save.TabIndex = 13
        Me.Bt_Save.Text = "SAVE"
        Me.Bt_Save.UseVisualStyleBackColor = True
        '
        'Bt_Delete
        '
        Me.Bt_Delete.Location = New System.Drawing.Point(151, 178)
        Me.Bt_Delete.Name = "Bt_Delete"
        Me.Bt_Delete.Size = New System.Drawing.Size(75, 23)
        Me.Bt_Delete.TabIndex = 14
        Me.Bt_Delete.Text = "DELETE"
        Me.Bt_Delete.UseVisualStyleBackColor = True
        '
        'Bt_Close
        '
        Me.Bt_Close.Location = New System.Drawing.Point(151, 213)
        Me.Bt_Close.Name = "Bt_Close"
        Me.Bt_Close.Size = New System.Drawing.Size(75, 23)
        Me.Bt_Close.TabIndex = 15
        Me.Bt_Close.Text = "CLOSE"
        Me.Bt_Close.UseVisualStyleBackColor = True
        '
        'DGV
        '
        Me.DGV.AllowUserToAddRows = False
        Me.DGV.AllowUserToDeleteRows = False
        Me.DGV.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DGV.Location = New System.Drawing.Point(445, 16)
        Me.DGV.Name = "DGV"
        Me.DGV.ReadOnly = True
        Me.DGV.Size = New System.Drawing.Size(441, 244)
        Me.DGV.TabIndex = 16
        '
        'Tx_Date
        '
        Me.Tx_Date.Location = New System.Drawing.Point(126, 249)
        Me.Tx_Date.Name = "Tx_Date"
        Me.Tx_Date.Size = New System.Drawing.Size(100, 20)
        Me.Tx_Date.TabIndex = 17
        '
        'Tx_Time
        '
        Me.Tx_Time.Location = New System.Drawing.Point(11, 249)
        Me.Tx_Time.Name = "Tx_Time"
        Me.Tx_Time.Size = New System.Drawing.Size(100, 20)
        Me.Tx_Time.TabIndex = 18
        '
        'GC1
        '
        GradientFillColor1.Color1 = System.Drawing.Color.Gainsboro
        GradientFillColor1.Color2 = System.Drawing.Color.DarkGray
        Me.GC1.Frame.BackColor = GradientFillColor1
        GradientFillColor2.BorderColor = System.Drawing.Color.Gainsboro
        GradientFillColor2.BorderWidth = 1
        GradientFillColor2.Color1 = System.Drawing.Color.White
        GradientFillColor2.Color2 = System.Drawing.Color.DimGray
        Me.GC1.Frame.FrameColor = GradientFillColor2
        Me.GC1.Frame.Style = DevComponents.Instrumentation.GaugeFrameStyle.Rectangular
        GaugeText1.BackColor.BorderColor = System.Drawing.Color.Black
        GaugeText1.Location = CType(resources.GetObject("GaugeText1.Location"), System.Drawing.PointF)
        GaugeText1.Name = "Text1"
        GaugeText1.Text = "°C"
        GaugeText2.BackColor.BorderColor = System.Drawing.Color.Black
        GaugeText2.Location = CType(resources.GetObject("GaugeText2.Location"), System.Drawing.PointF)
        GaugeText2.Name = "Text2"
        GaugeText2.Text = "°F"
        GaugeText2.Visible = False
        Me.GC1.GaugeItems.AddRange(New DevComponents.Instrumentation.GaugeItem() {GaugeText1, GaugeText2})
        GaugeLinearScale1.Labels.FormatString = "0°"
        GaugeLinearScale1.Location = CType(resources.GetObject("GaugeLinearScale1.Location"), System.Drawing.PointF)
        GaugeLinearScale1.MajorTickMarks.Layout.Placement = DevComponents.Instrumentation.DisplayPlacement.Near
        GaugeLinearScale1.MajorTickMarks.Layout.Style = DevComponents.Instrumentation.GaugeMarkerStyle.Rectangle
        GaugeLinearScale1.MajorTickMarks.Layout.Width = 0.008!
        GaugeLinearScale1.MaxPin.Name = "MaxPin"
        GaugeLinearScale1.MaxPin.Visible = False
        GaugeLinearScale1.MaxValue = 80.0R
        GaugeLinearScale1.MinorTickMarks.Layout.Placement = DevComponents.Instrumentation.DisplayPlacement.Near
        GaugeLinearScale1.MinorTickMarks.Layout.Width = 0.016!
        GaugeLinearScale1.MinPin.Name = "MinPin"
        GaugeLinearScale1.MinPin.Visible = False
        GaugeLinearScale1.MinValue = 20.0R
        GaugeLinearScale1.Name = "Scale1"
        GaugeLinearScale1.Orientation = System.Windows.Forms.Orientation.Vertical
        GaugePointer1.BulbOffset = 0.026!
        GaugePointer1.BulbSize = 0.132!
        GaugePointer1.CapFillColor.BorderColor = System.Drawing.Color.DimGray
        GaugePointer1.CapFillColor.BorderWidth = 1
        GaugePointer1.CapFillColor.Color1 = System.Drawing.Color.WhiteSmoke
        GaugePointer1.CapFillColor.Color2 = System.Drawing.Color.DimGray
        GaugePointer1.FillColor.BorderColor = System.Drawing.Color.Black
        GaugePointer1.FillColor.BorderWidth = 1
        GaugePointer1.FillColor.Color1 = System.Drawing.Color.Red
        GaugePointer1.Name = "Pointer1"
        GaugePointer1.Style = DevComponents.Instrumentation.PointerStyle.Thermometer
        GaugePointer1.ThermoBackColor.Color1 = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer))
        GaugePointer1.Value = 12.0R
        GaugePointer1.Width = 0.1!
        GaugeLinearScale1.Pointers.AddRange(New DevComponents.Instrumentation.GaugePointer() {GaugePointer1})
        GaugeSection1.FillColor.Color1 = System.Drawing.Color.SteelBlue
        GaugeSection1.FillColor.Color2 = System.Drawing.Color.LightCyan
        GaugeSection1.FillColor.GradientFillType = DevComponents.Instrumentation.GradientFillType.VerticalCenter
        GaugeSection1.Name = "Section1"
        GaugeLinearScale1.Sections.AddRange(New DevComponents.Instrumentation.GaugeSection() {GaugeSection1})
        GaugeLinearScale1.Size = New System.Drawing.SizeF(0.75!, 0.75!)
        GaugeLinearScale1.Width = 0.1!
        GaugeLinearScale2.Labels.FormatString = "0°"
        GaugeLinearScale2.Labels.Layout.Placement = DevComponents.Instrumentation.DisplayPlacement.Far
        GaugeLinearScale2.Labels.ShowMaxLabel = False
        GaugeLinearScale2.Labels.ShowMinLabel = False
        GaugeLinearScale2.Location = CType(resources.GetObject("GaugeLinearScale2.Location"), System.Drawing.PointF)
        GaugeLinearScale2.MajorTickMarks.Interval = 20.0R
        GaugeLinearScale2.MajorTickMarks.IntervalOffset = 2.0R
        GaugeLinearScale2.MajorTickMarks.Layout.Placement = DevComponents.Instrumentation.DisplayPlacement.Far
        GaugeLinearScale2.MajorTickMarks.Layout.Style = DevComponents.Instrumentation.GaugeMarkerStyle.Rectangle
        GaugeLinearScale2.MajorTickMarks.Layout.Width = 0.008!
        GaugeLinearScale2.MaxPin.Name = "MaxPin"
        GaugeLinearScale2.MaxPin.Visible = False
        GaugeLinearScale2.MaxValue = 176.0R
        GaugeLinearScale2.MinorTickMarks.Interval = 4.0R
        GaugeLinearScale2.MinorTickMarks.IntervalOffset = 2.0R
        GaugeLinearScale2.MinorTickMarks.Layout.Placement = DevComponents.Instrumentation.DisplayPlacement.Far
        GaugeLinearScale2.MinorTickMarks.Layout.Width = 0.016!
        GaugeLinearScale2.MinPin.Name = "MinPin"
        GaugeLinearScale2.MinPin.Visible = False
        GaugeLinearScale2.MinValue = 68.0R
        GaugeLinearScale2.Name = "Scale2"
        GaugeLinearScale2.Orientation = System.Windows.Forms.Orientation.Vertical
        GaugeLinearScale2.Size = New System.Drawing.SizeF(0.75!, 0.75!)
        GaugeLinearScale2.Width = 0.1!
        Me.GC1.LinearScales.AddRange(New DevComponents.Instrumentation.GaugeLinearScale() {GaugeLinearScale1, GaugeLinearScale2})
        Me.GC1.Location = New System.Drawing.Point(243, 12)
        Me.GC1.Name = "GC1"
        Me.GC1.Size = New System.Drawing.Size(92, 248)
        Me.GC1.TabIndex = 19
        Me.GC1.Text = "Termometer"
        '
        'GC2
        '
        Me.GC2.ForeColor = System.Drawing.SystemColors.ActiveCaption
        GradientFillColor3.Color1 = System.Drawing.Color.Gainsboro
        GradientFillColor3.Color2 = System.Drawing.Color.DarkGray
        Me.GC2.Frame.BackColor = GradientFillColor3
        GradientFillColor4.BorderColor = System.Drawing.Color.Gainsboro
        GradientFillColor4.BorderWidth = 1
        GradientFillColor4.Color1 = System.Drawing.Color.White
        GradientFillColor4.Color2 = System.Drawing.Color.DimGray
        Me.GC2.Frame.FrameColor = GradientFillColor4
        Me.GC2.Frame.Style = DevComponents.Instrumentation.GaugeFrameStyle.Rectangular
        GaugeCustomLabel1.Layout.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        GaugeCustomLabel1.Name = "ACID"
        GaugeCustomLabel1.Text = "ACID"
        GaugeCustomLabel1.Value = 3.0R
        GaugeCustomLabel2.Layout.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        GaugeCustomLabel2.Name = "NETRAL"
        GaugeCustomLabel2.Text = "NETRAL"
        GaugeCustomLabel2.Value = 7.0R
        GaugeCustomLabel3.Layout.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        GaugeCustomLabel3.Name = "BASES"
        GaugeCustomLabel3.Text = "BASES"
        GaugeCustomLabel3.Value = 10.0R
        GaugeLinearScale3.CustomLabels.AddRange(New DevComponents.Instrumentation.GaugeCustomLabel() {GaugeCustomLabel1, GaugeCustomLabel2, GaugeCustomLabel3})
        GaugeLinearScale3.Labels.Layout.ScaleOffset = 0.03!
        GaugeLinearScale3.Location = CType(resources.GetObject("GaugeLinearScale3.Location"), System.Drawing.PointF)
        GaugeLinearScale3.MaxPin.Name = "MaxPin"
        GaugeLinearScale3.MaxPin.Visible = False
        GaugeLinearScale3.MaxValue = 14.0R
        GaugeLinearScale3.MinPin.Name = "MinPin"
        GaugeLinearScale3.MinPin.Visible = False
        GaugeLinearScale3.Name = "Scale1"
        GaugeLinearScale3.Orientation = System.Windows.Forms.Orientation.Vertical
        GaugePointer2.CapFillColor.BorderColor = System.Drawing.Color.DimGray
        GaugePointer2.CapFillColor.BorderWidth = 1
        GaugePointer2.CapFillColor.Color1 = System.Drawing.Color.WhiteSmoke
        GaugePointer2.CapFillColor.Color2 = System.Drawing.Color.DimGray
        GaugePointer2.FillColor.BorderColor = System.Drawing.Color.DimGray
        GaugePointer2.FillColor.BorderWidth = 1
        GaugePointer2.FillColor.Color1 = System.Drawing.Color.Red
        GaugePointer2.Name = "Pointer1"
        GaugePointer2.Placement = DevComponents.Instrumentation.DisplayPlacement.Far
        GaugePointer2.ScaleOffset = 0.05!
        GaugePointer2.ThermoBackColor.BorderColor = System.Drawing.Color.Black
        GaugePointer2.ThermoBackColor.BorderWidth = 1
        GaugePointer2.ThermoBackColor.Color1 = System.Drawing.Color.FromArgb(CType(CType(100, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer), CType(CType(60, Byte), Integer))
        GaugeLinearScale3.Pointers.AddRange(New DevComponents.Instrumentation.GaugePointer() {GaugePointer2})
        GaugeSection2.FillColor.Color1 = System.Drawing.Color.CornflowerBlue
        GaugeSection2.FillColor.Color2 = System.Drawing.Color.Purple
        GaugeSection2.Name = "Section1"
        GaugeLinearScale3.Sections.AddRange(New DevComponents.Instrumentation.GaugeSection() {GaugeSection2})
        Me.GC2.LinearScales.AddRange(New DevComponents.Instrumentation.GaugeLinearScale() {GaugeLinearScale3})
        Me.GC2.Location = New System.Drawing.Point(341, 12)
        Me.GC2.Name = "GC2"
        Me.GC2.Size = New System.Drawing.Size(98, 248)
        Me.GC2.TabIndex = 20
        Me.GC2.Text = "pH level"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(891, 281)
        Me.Controls.Add(Me.GC2)
        Me.Controls.Add(Me.GC1)
        Me.Controls.Add(Me.Tx_Time)
        Me.Controls.Add(Me.Tx_Date)
        Me.Controls.Add(Me.DGV)
        Me.Controls.Add(Me.Bt_Close)
        Me.Controls.Add(Me.Bt_Delete)
        Me.Controls.Add(Me.Bt_Save)
        Me.Controls.Add(Me.Pc_Status)
        Me.Controls.Add(Me.Lb_suhu)
        Me.Controls.Add(Me.Lb_ph)
        Me.Controls.Add(Me.Lb_data)
        Me.Controls.Add(Me.Tx_pH)
        Me.Controls.Add(Me.Tx_data)
        Me.Controls.Add(Me.Tx_suhu)
        Me.Controls.Add(Me.Bt_Disconnect)
        Me.Controls.Add(Me.Bt_Connect)
        Me.Controls.Add(Me.Cb_Baud)
        Me.Controls.Add(Me.Bt_Baud)
        Me.Controls.Add(Me.Cb_Scan)
        Me.Controls.Add(Me.Bt_Scan)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Form1"
        Me.Text = "Monitoring"
        CType(Me.Pc_Status, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DGV, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GC1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GC2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Bt_Scan As System.Windows.Forms.Button
    Friend WithEvents Cb_Scan As System.Windows.Forms.ComboBox
    Friend WithEvents Cb_Baud As System.Windows.Forms.ComboBox
    Friend WithEvents Bt_Baud As System.Windows.Forms.Button
    Friend WithEvents Bt_Connect As System.Windows.Forms.Button
    Friend WithEvents Bt_Disconnect As System.Windows.Forms.Button
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Tx_suhu As System.Windows.Forms.TextBox
    Friend WithEvents Tx_data As System.Windows.Forms.TextBox
    Friend WithEvents Tx_pH As System.Windows.Forms.TextBox
    Friend WithEvents Lb_data As System.Windows.Forms.Label
    Friend WithEvents Lb_ph As System.Windows.Forms.Label
    Friend WithEvents Lb_suhu As System.Windows.Forms.Label
    Friend WithEvents Pc_Status As System.Windows.Forms.PictureBox
    Friend WithEvents Bt_Save As System.Windows.Forms.Button
    Friend WithEvents Bt_Delete As System.Windows.Forms.Button
    Friend WithEvents Bt_Close As System.Windows.Forms.Button
    Friend WithEvents DGV As System.Windows.Forms.DataGridView
    Friend WithEvents Tx_Date As System.Windows.Forms.TextBox
    Friend WithEvents Tx_Time As System.Windows.Forms.TextBox
    Friend WithEvents GC1 As DevComponents.Instrumentation.GaugeControl
    Friend WithEvents GC2 As DevComponents.Instrumentation.GaugeControl

End Class
