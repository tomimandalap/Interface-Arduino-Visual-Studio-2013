﻿Public Class Form1
    Private readBuffer As String = String.Empty
    Private Bytenumber As Integer
    Private BytetoRead As Integer
    Private byteEnd(2) As Char
    Dim strinput As String
    Dim prosesoff As Boolean = False
    Dim disconnect As Boolean = False
    Dim data(2) As String 'banyak data yang akan ditampilkan
    Dim Value1 As Integer
    Dim Value2 As Integer

    Sub Tampilan()
        Call KoneksiDB()
        DA = New OleDb.OleDbDataAdapter("select * from data", CONN)
        DS = New DataSet
        DS.Clear()
        DA.Fill(DS, "data")
        DGV.DataSource = DS.Tables("data")
        DGV.ReadOnly = True
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.CenterToParent()
        Bt_Connect.Enabled = False
        Bt_Connect.BringToFront()

        Bt_Disconnect.Enabled = False
        Bt_Disconnect.SendToBack()

        Cb_Baud.SelectedItem = "115200"
        Call Tampilan()
    End Sub

    Private Sub Bt_Scan_Click(sender As Object, e As EventArgs) Handles Bt_Scan.Click
        Cb_Scan.Items.Clear()
        Dim myPort As Array
        Dim i As Integer
        myPort = IO.Ports.SerialPort.GetPortNames()
        Cb_Scan.Items.AddRange(myPort)
        i = Cb_Scan.Items.Count
        i = i - i
        Try
            Cb_Scan.SelectedIndex = i
        Catch ex As Exception
            Dim result As DialogResult
            result = MessageBox.Show("Com Port is not detected", "WARNING !!!", MessageBoxButtons.OK)
            Cb_Scan.Text = ""
            Cb_Scan.Items.Clear()
            Call Form1_Load(Me, e)
        End Try
        Bt_Connect.Enabled = True
        Bt_Connect.BringToFront()
        Cb_Scan.DroppedDown = True
    End Sub

    Private Sub Bt_Connect_Click(sender As Object, e As EventArgs) Handles Bt_Connect.Click
        Bt_Connect.Enabled = False
        Bt_Connect.SendToBack()

        SerialPort1.BaudRate = Cb_Baud.SelectedItem
        SerialPort1.PortName = Cb_Scan.SelectedItem
        SerialPort1.Open()
        Timer1.Start()
        Timer2.Stop()

        Pc_Status.BackColor = Color.Green
        Bt_Disconnect.Enabled = True
        Bt_Disconnect.BringToFront()
    End Sub

    Private Sub Bt_Disconnect_Click(sender As Object, e As EventArgs) Handles Bt_Disconnect.Click
        Bt_Disconnect.Enabled = False
        Bt_Disconnect.SendToBack()

        Timer1.Stop()
        Timer2.Start()
        SerialPort1.Close()

        Pc_Status.BackColor = Color.Red
        Bt_Connect.Enabled = True
        Bt_Connect.BringToFront()
        Tx_data.Text = ""
        Tx_Time.Text = ""
        Tx_Date.Text = ""
        Tx_pH.Text = "00.00"
        Tx_suhu.Text = "00.00"
    End Sub

    Private Sub SerialPort1_DataReceived(sender As Object, e As IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived
        If SerialPort1.IsOpen Then
            Try
                byteEnd = SerialPort1.NewLine.ToCharArray
                Bytenumber = SerialPort1.BytesToRead
                readBuffer = SerialPort1.ReadLine()

                Me.Invoke(New EventHandler(AddressOf DoUpdate))
            Catch ex As Exception
                'MsgBox ("READ" & ex.Message)
            End Try
        End If
    End Sub

    Private Sub DoUpdate(ByVal sender As Object, ByVal e As System.EventArgs)
        Timer1.Enabled = True
        Call proses_fix()

        If disconnect Then
            prosesoff = True
        End If
    End Sub

    Private Sub proses_fix()
        strinput = Tx_data.Text
        Dim panjang_data As Integer
        Dim x As Integer
        Dim z As Integer
        strinput = Tx_pH.Text
        panjang_data = Len(Tx_pH.Text)

        Dim i As Integer
        i = 0
        z = 0

        For x = 1 To Len(readBuffer$)
            If Mid(readBuffer$, x, 1) = "," Then
                z = z + 1
                data(i) = Mid(readBuffer$, z, x - z)
                i = i + 1
                z = x
            End If
        Next x
    End Sub

    Private Sub Timer1_Tick(sender As Object, e As EventArgs) Handles Timer1.Tick
        Tx_Date.Text = Format(Now, "dd/MM/yyyy")
        Tx_Time.Text = Format(Now, "HH:mm:ss")
        If SerialPort1.IsOpen Then
            Tx_data.Text = readBuffer
            Tx_pH.Text = data(0)
            Tx_suhu.Text = data(1)

            Value1 = (data(0))
            Value2 = Convert.ToDecimal(data(1))

            GC1.SetPointerValue("Scale1", "Pointer1", Value1)
            GC2.SetPointerValue("Scale1", "Pointer1", Value2)
        End If
    End Sub

    Private Sub Timer2_Tick(sender As Object, e As EventArgs) Handles Timer2.Tick
        If prosesoff Then
            SerialPort1.Close()
            Timer2.Enabled = False
            Tx_data.Text = " "
        End If
    End Sub

    Private Sub Bt_Close_Click(sender As Object, e As EventArgs) Handles Bt_Close.Click
        Me.Close()
    End Sub

    Private Sub Bt_Save_Click(sender As Object, e As EventArgs) Handles Bt_Save.Click
        If Tx_Time.Text = "" Or Tx_Date.Text = "" Or Tx_pH.Text = "" Or Tx_suhu.Text = "" Then
            MsgBox("Data incomplete!")
        Else
            Call koneksiDB()
            Dim simpan As String = "insert into data values ('" & Tx_Time.Text & "','" & Tx_Date.Text & "','" & Tx_pH.Text & "','" & Tx_suhu.Text & "')"
            CMD = New OleDb.OleDbCommand(simpan, CONN)
            CMD.ExecuteNonQuery()
            MsgBox("Data saved", MsgBoxStyle.Information, "INFORMATION")
            Call Tampilan()
        End If
    End Sub

    Private Sub Bt_Delete_Click(sender As Object, e As EventArgs) Handles Bt_Delete.Click
        If Tx_Time.Text = "" Or Tx_Date.Text = "" Or Tx_pH.Text = "" Or Tx_suhu.Text = "" Then
            MsgBox("Data incomplete!")
        Else
            Call koneksiDB()
            Dim hapus As String = "delete from data where TIME= '" & Tx_Time.Text & "'"
            CMD = New OleDb.OleDbCommand(hapus, CONN)
            CMD.ExecuteNonQuery()
            MsgBox("Data successfully delete", MsgBoxStyle.Information, "INFPRMATION")
            Call Tampilan()
        End If
    End Sub

    Private Sub DGV_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DGV.CellContentClick
        Call koneksiDB()
        Dim i As Integer
        i = DGV.CurrentRow.Index
        CMD = New OleDb.OleDbCommand("Select * from data where TIME='" & DGV.Item(0, i).Value & "'", CONN)
        DR = CMD.ExecuteReader
        DR.Read()
        If Not DR.HasRows Then
            Tx_Time.Focus()
        Else
            Tx_Time.Text = DR.Item("TIME")
            Tx_Date.Text = DR.Item("DATE")
            Tx_pH.Text = DR.Item("PH")
            Tx_suhu.Text = DR.Item("TEMP")
            Tx_Time.Focus()
        End If
    End Sub

End Class
