﻿Imports System.Data.OleDb
Module ModuleKU
    Public CONN As OleDbConnection
    Public DA As OleDbDataAdapter
    Public DS As DataSet
    Public CMD As OleDbCommand
    Public DR As OleDbDataReader

    Sub koneksiDB()
        Try
            CONN = New OleDbConnection("provider=microsoft.ace.Oledb.12.0; data source=Arduino.accdb")
            CONN.Open()
            'MsgBox("Connection database SUCCES")
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
    End Sub
End Module
